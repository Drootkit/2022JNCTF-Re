flag consists of two parts, connected by “%” in the middle.
examlpe：JNCTF{part1%part2}